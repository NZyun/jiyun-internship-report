const helloWorld = () => {
  console.log("Hello World");
};

helloWorld();
