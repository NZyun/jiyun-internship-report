# GD3 Starterkit

You will find on this repo a starterkit to use for starting a coding project or a prototype. Next to this `README.md` file, you will find an `index.html` file and an `assets/` folder, where the `CSS` and `Javascript` are located, alongside font files and images.

To use it on your own project, you can clone it on your Desktop by typing this command in the Terminal of VS Code:

```
cd Desktop && git clone https://github.com/quentin-f451/gd3-coding-starterkit.git
```

Or you can just download it by clicking the green button "Code" on top of this page.

From there, you can move it, modify it and do whatever you want with it!
